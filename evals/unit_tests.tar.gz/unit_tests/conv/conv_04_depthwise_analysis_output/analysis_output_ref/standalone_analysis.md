# TraceLens Standalone Analysis Report

**Trace:** `conv_04_depthwise.json`
**Platform:** MI300X
**Total GPU Time:** 0.35 ms
**Analysis Date:** 2026-03-19

---

## Executive Summary

Standalone performance analysis of convolution trace `conv_04_depthwise` on MI300X. The trace contains a single depthwise `aten::convolution` with input [8, 1024, 32, 32], weight [1024, 1, 3, 3], groups=1024. The operation achieves only 0.26% of peak FP32 compute (0.43 TFLOPS vs 163 TFLOPS peak) and 3.6% of peak HBM bandwidth (0.19 TB/s vs 5.3 TB/s peak). The depthwise convolution is inherently memory-bound (FLOPS/Byte = 2.25) and the specialized `depthwise_conv2d_fwd_fp32_kernel` shows severe under-utilization of the memory subsystem, which is characteristic of small depthwise workloads with limited parallel work.

| Metric | Value |
|--------|-------|
| Total GPU Kernel Time | 0.35 ms |
| Total CPU Duration | 0.55 ms |
| Computation | 100.0% |
| Idle Time | 0.0% |
| Exposed Communication | 0.0% |
| Top Bottleneck Category | Convolution (0.35 ms, 100% of compute) |

---

## Compute Kernel Optimizations

### 1. Convolution (100% of compute — 0.35 ms)

**Status:** OK

**Overview:**
Single depthwise `aten::convolution`. Input [8, 1024, 32, 32], weight [1024, 1, 3, 3], FP32. Stride=(1,1), padding=(1,1), dilation=(1,1), groups=1024. Memory-bound workload achieving 3.6% of peak HBM bandwidth.

**Time Breakdown:**
- GPU kernel time: 0.35 ms
- CPU duration: 0.55 ms (CPU/GPU ratio: 1.57x — no sync bottleneck)
- Sync time: 0 ms

**Top Operations:**

| Rank | Operation | Category | Time (ms) | % of Compute |
|------|-----------|----------|-----------|--------------|
| 1 | aten::convolution (depthwise) [8,1024,32,32]×[1024,1,3,3] | Convolution | 0.350 | 100.0% |

**Operations Breakdown:**

| Operation | Count | Time (ms) | % of Category | Bound | FLOPS/Byte | Achieved TB/s | Achieved TFLOPS | Peak TB/s | Peak TFLOPS |
|-----------|-------|-----------|---------------|-------|------------|---------------|-----------------|-----------|-------------|
| aten::convolution (depthwise) | 1 | 0.350 | 100.0% | memory | 2.25 | 0.19 | 0.43 | 5.3 | 163 (FP32) |

**Key Bottleneck: aten::convolution — Depthwise with Severe Bandwidth Under-utilization**

- **Time:** 0.35 ms (100% of compute)
- **Shape:** Input [8, 1024, 32, 32], Weight [1024, 1, 3, 3], FP32, Groups=1024
- **Params:** Stride=(1,1), Padding=(1,1), Dilation=(1,1), No bias
- **Kernel:** `depthwise_conv2d_fwd_fp32_kernel`, grid=[256,1,1], block=[256,1,1]
- **HBM BW:** 0.19 TB/s achieved vs 5.3 TB/s peak (3.6% of peak)
- **Compute:** 0.43 TFLOPS achieved vs 163 TFLOPS peak (0.26% of peak FP32)
- **Bound type:** Memory-bound (FLOPS/Byte = 2.25)
- **Transpose overhead:** 0% — no layout-mismatch signal

**Analysis:** Depthwise convolutions have minimal arithmetic intensity (2.25 FLOPS/Byte) and are inherently memory-bound. Achieving only 3.6% of peak HBM bandwidth indicates severe kernel under-utilization — likely poor memory coalescing, low wavefront occupancy, or suboptimal tiling for the 32×32 spatial tiles across 1024 channels. The small grid size [256,1,1] may not fill the GPU sufficiently.

---

## System-Level Optimizations

> **Note:** System-level analysis is exploratory. The patterns and recommendations below are under active development and may be refined as system-level analysis matures.

### GPU Idle Time

GPU idle time is **0.0%** (0.0 ms out of 0.35 ms total). No GPU idle reduction actions are needed.

| Metric | Value |
|--------|-------|
| Total Time | 0.35 ms |
| Computation | 100.0% |
| Idle | 0.0% |
| Communication | 0.0% |
| MemCpy | 0.0% |

### Multi-Kernel Issues

No multi-kernel issues detected:
- **Memcpy events:** 0 (no D2H/H2D transfers)
- **Collective communication events:** 0
- **Exposed communication time:** 0.0%
- **Exposed memcpy time:** 0.0%

### Host-Side Observation

Host-side CPU duration (~550 µs) exceeds GPU kernel time (~350 µs), consistent with launch and framework overhead around a single kernel invocation. This is **not** a GPU idle issue but standard per-launch overhead. In production workloads, consider GPU graph capture or batching more work per launch to amortize this cost.

---

## Detailed Analysis: Compute Kernels

### Convolution — Depthwise Conv2D FP32

The single `aten::convolution` operation performs a **depthwise** 2D convolution (groups=1024), meaning each channel has its own 3×3 filter with no cross-channel computation. This results in very low arithmetic intensity (2.25 FLOPS/Byte).

**Kernel details:**
- GPU kernel: `depthwise_conv2d_fwd_fp32_kernel`
- Stream: 7
- Launch config: grid=[256,1,1], block=[256,1,1]
- Data moved: 64.04 MB
- GFLOPS: 0.151

**Performance characterization:**
- The operation is **memory-bound** with FLOPS/Byte = 2.25, well below the MI300X balance point of ~30.8 FLOPS/Byte (163 TFLOPS / 5.3 TB/s)
- Achieved memory bandwidth (0.19 TB/s) is ~3.6% of peak HBM (5.3 TB/s)
- The small grid launch [256,1,1] provides limited GPU occupancy for a device with 304 compute units

**Optimization opportunities:**
1. **Fusion:** Fuse depthwise conv with adjacent pointwise convolution or normalization ops in a full model (depthwise-separable block pattern)
2. **Precision:** Evaluate FP16/BF16 depthwise paths if accuracy permits — can improve throughput and reduce memory traffic
3. **Occupancy:** Larger batch sizes or batched depthwise patterns improve GPU utilization
4. **Memory access:** Profile read/write coalescing and wavefront occupancy; depthwise kernels are harder to saturate than standard dense convolutions
5. **Layout:** channels_last memory format may improve spatial locality, though no transpose overhead indicates the current layout is not causing extra copies

---

## Detailed Analysis: System-Level

No system-level bottlenecks were identified in this trace. The workload is a single GPU kernel with no communication, memcpy, or idle time. The 0% idle classification confirms full GPU utilization within the traced window.

---

## Impact Summary

| Recommendation | Type | Estimated Savings (ms) | Confidence |
|---------------|------|----------------------|------------|
| Optimize depthwise kernel memory access patterns and occupancy | kernel_tuning | ~0.34 (closing to 100% roofline) | Low |
| Evaluate FP16/BF16 precision for depthwise path | algorithmic | Model-dependent | Low |
| Fuse depthwise + pointwise in full model context | algorithmic | Model-dependent | Low |

**Note:** Impact estimates for this unit test trace are limited by the very small absolute time (0.35 ms). The significance of these optimizations depends on how frequently this depthwise convolution pattern appears in the full model workload.

---

## Appendix

### Hardware Specifications

| Spec | Value |
|------|-------|
| **Platform** | AMD Instinct MI300X |
| **Memory** | 192 GB HBM3 |
| **Peak HBM Bandwidth** | 5.3 TB/s |
| **Peak TFLOPS (FP8)** | 1,273 |
| **Peak TFLOPS (INT8)** | 2,600 |
| **Peak TFLOPS (FP16)** | 654 |
| **Peak TFLOPS (BF16)** | 708 |
| **Peak TFLOPS (FP32)** | 163 |
| **Peak TFLOPS (FP64)** | 81 |
| **Vector TFLOPS (FP16)** | 163 |
| **Vector TFLOPS (BF16)** | 163 |
| **Vector TFLOPS (FP32)** | 81 |
| **Vector TFLOPS (FP64)** | 40 |

### Validation Summary

| Check | Status |
|-------|--------|
| Time Sanity | PASS |
| Efficiency Anomalies | PASS (no efficiency > 100%) |
| Coverage | PASS (100% of compute time analyzed) |
| Priority Consistency | INFO — Top by GPU time: [convolution] |

---

*Report generated by TraceLens AgenticMode Standalone Analysis*
