<!--
Copyright (c) 2024 - 2025 Advanced Micro Devices, Inc. All rights reserved.

See LICENSE for license information.
-->

# Workload - MI300X Standalone Analysis

## Executive Summary

This trace captures a single transposed 2D convolution (`aten::convolution`) and a small elementwise multiply (`aten::mul_`) on MI300X. Total GPU compute time is 1.89 ms, split roughly 52% computation and 48% idle. The convolution dominates compute at 47.6% but achieves only 0.73% of peak FP32 matrix throughput due to the tiny workload size (1 GFLOP in a single 0.9 ms kernel). System-level idle is elevated (47.6%) but driven by the micro-trace window rather than a sustained pipeline issue.

| Metric | Value |
|--------|-------|
| Total Compute Time | 1.89 ms |
| Computation | 52.4% |
| Idle Time | 47.6% |
| Exposed Communication | 0.0% |
| Top Bottleneck Category | Convolution (47.6%) |

---

## Compute Kernel Optimizations

Findings from per-category kernel analysis (Convolution, Elementwise).

### Top Operations

| Rank | Category | Time (ms) | % of Compute Time | Ops | Potential improvement (time, E2E %) |
|------|----------|-----------|-------------------|-----|-------------------------------------|
| 1 | Convolution | 0.90 | 90.9% | 1 | — |
| 2 | Elementwise | 0.09 | 9.1% | 3 | — |

### 🔴 P1: Transposed Convolution Far Below Roofline (0.73% of Peak FP32)

**Insight**: The single `aten::convolution` (transposed, FP32, 4×512×8×8 input, 512×256×4×4 weights) achieves 1.19 TFLOPS vs 163 TFLOPS peak matrix FP32 — 0.73% utilization. The kernel (`igemm_bwd_data_gtcx_nhwc_fp32`) is compute-bound (FLOPS/Byte = 107.8) but too small to saturate the device.

**Action**: If this transposed conv is a hot path in a full model, increase batch size or spatial dimensions to better amortize launch overhead and fill GPU tiles. Consider BF16/FP16 precision (higher peak TFLOPS on MI300X) if numerically acceptable.

**Impact**: Not quantifiable from trace data — no kernel_tuning estimates available for this workload size.

→ *See [Detailed Analysis: Compute Kernels > 1. Convolution](#1-convolution-909-of-compute) for details*

---

### 🟡 P2: Elementwise Multiply with Low HBM Utilization

**Insight**: `aten::mul_` (3 invocations, 256×1024 FP32 tensors) is memory-bound (FLOPS/Byte = 0.08) and achieves 0.1 TB/s vs 5.3 TB/s peak HBM — 1.9% utilization. However, at 0.09 ms total (9.1% of compute), the absolute time is negligible.

**Action**: If similar micro-kernels repeat frequently at scale, fuse with adjacent elementwise ops to reduce launch overhead. Do not invest in kernel-level tuning for this workload size in isolation.

**Impact**: Not quantifiable from trace data.

→ *See [Detailed Analysis: Compute Kernels > 2. Elementwise](#2-elementwise-91-of-compute) for details*

---

## System-Level Optimizations

> **Note:** System-level analysis is exploratory. The patterns and recommendations below are under active development and may be refined as system-level analysis matures.

### 🔴 P1: High GPU Idle Time (47.6%)

**Insight**: GPU idle time is 47.6% (0.9 ms of 1.89 ms total), exceeding the 15% threshold. No communication or memcpy exposure exists — idle is driven by CPU-side overhead and launch gaps between kernels. The elementwise path shows a 7.7× CPU-to-GPU-kernel time ratio, indicating host/framework overhead dominates.

**Action**: Batch sequences of small operations using GPU graph capture or fused paths to cut per-launch overhead. Reduce unnecessary device synchronization and favor asynchronous queues. Validate on a longer trace region, as sub-2 ms windows amplify fixed costs.

→ *See [Detailed Analysis: System-Level > CPU/Idle Time](#cpu-idle-time-analysis) for details*

---

## Detailed Analysis: Compute Kernels

### 1. Convolution (90.9% of compute)

Single transposed 2D convolution consuming 0.9 ms of GPU kernel time. The kernel is compute-bound with high arithmetic intensity but achieves very low utilization due to the tiny FLOP count.

| Operation | Kernel time (ms) | % of category | Count | FLOPS/Byte | Efficiency | Potential improvement (time, E2E %) |
|-----------|-----------------|---------------|-------|------------|------------|-------------------------------------|
| aten::convolution | 0.90 | 100% | 1 | 107.79 | 0.73% of 163 TFLOPS peak (matrix FP32) | — |

**Kernel details**: `igemm_bwd_data_gtcx_nhwc_fp32_bx0_bt128x128x16` — backward-data style implementation used for transposed convolution. Input: 4×512×8×8, Weights: 512×256×4×4, stride (2,2), padding (1,1), groups=1.

**Key observations**:
- Compute-bound (FLOPS/Byte = 107.79) but only 1.07 GFLOP total — insufficient to fill MI300X CUs
- No separate layout-transpose overhead detected (0%); "transposed" refers to deconvolution semantics
- Achieved 1.19 TFLOPS; gap to roofline is driven by workload size, not algorithmic inefficiency

### 2. Elementwise (9.1% of compute)

Three invocations of `aten::mul_` on 256×1024 FP32 tensors, totaling 0.09 ms GPU kernel time.

| Operation | Kernel time (ms) | % of category | Count | FLOPS/Byte | Efficiency | Potential improvement (time, E2E %) |
|-----------|-----------------|---------------|-------|------------|------------|-------------------------------------|
| aten::mul_ | 0.09 | 100% | 3 | 0.08 | 1.89% of 5.3 TB/s peak HBM | — |

**Key observations**:
- Memory-bound (FLOPS/Byte = 0.08), well below the MI300X ridge point
- CPU duration (0.69 ms) and sync time (0.60 ms) greatly exceed GPU kernel time (0.09 ms) — host overhead dominates
- Achieved 0.1 TB/s; low utilization is expected for micro-kernels moving ~3 MB total

---

## Detailed Analysis: System-Level

> **Note:** System-level analysis is exploratory. The patterns and recommendations below are under active development and may be refined as system-level analysis matures.

<a id="cpu-idle-time-analysis"></a>
### 1. CPU/Idle Time Analysis

GPU idle time of 47.6% (0.9 ms) on a 1.89 ms total window. No communication or memcpy activity was detected.

| Metric | Value |
|--------|-------|
| Total GPU Time | 1.89 ms |
| Computation | 52.4% (0.99 ms) |
| Idle | 47.6% (0.90 ms) |
| Communication | 0.0% |
| Memcpy | 0.0% |

**Category CPU overhead**:

| Category | GPU kernel (ms) | CPU duration (ms) | CPU/GPU ratio |
|----------|----------------|-------------------|---------------|
| Convolution | 0.90 | 1.10 | 1.22× |
| Elementwise | 0.09 | 0.69 | 7.67× |

**Primary drivers**: High idle with zero NCCL/memcpy exposure indicates the gap is CPU-side launch and synchronization overhead. The elementwise path shows disproportionate CPU time relative to GPU kernel time.

**Caveat**: Sub-2 ms traces amplify the impact of fixed launch and synchronization costs. Validate idle percentage on longer steady-state regions.

<a id="multi-kernel-issues"></a>
### 2. Multi-Kernel Issues

No multi-kernel issues detected. Zero memcpy transfers and zero NCCL collective operations were observed in this trace. Communication/compute overlap is not applicable.

| Metric | Value |
|--------|-------|
| Memcpy count | 0 |
| NCCL count | 0 |
| Exposed comm time | 0 µs |
| Exposed memcpy time | 0 µs |

---

## Appendix

### Model Architecture
- **Model**: Cannot be inferred from trace
- **Architecture**: Cannot be inferred from trace
- **Scale**: Cannot be inferred from trace
- **Precision**: Cannot be inferred from trace

### Hardware Reference
- **Platform**: MI300X
- **Peak HBM BW**: 5.3 TB/s
- **Peak MAF (FP32)**: 163 TFLOPS
- **Peak MAF (BF16)**: 708 TFLOPS
- **Peak MAF (FP16)**: 654 TFLOPS
