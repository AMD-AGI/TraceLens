# conv_06_large_dilation — MI300X Standalone Analysis

## Executive Summary

Standalone performance analysis of synthetic test trace `conv_06_large_dilation` on MI300X. The trace contains 2 compute kernel categories and 0 system-level categories.

| Metric | Value |
|--------|-------|
| Total Compute Time | 3.19 ms |
| Computation | 71.8% |
| Idle Time | 28.2% |
| Exposed Communication | 0.0000% |
| Top Bottleneck Category | Convolution (2.200 ms) |

---

## Compute Kernel Optimizations

### Top Operations

| Rank | Category | GPU Time (ms) | % of Compute |
|------|----------|---------------|--------------|
| 1 | Convolution | 2.200 | 96.1% |
| 2 | elementwise | 0.090 | 3.9% |

### 🔴 P1: Convolution Optimization

**Issue**: Convolution operations at 10.8% average efficiency, consuming 2.200 ms (69.0% of compute).

**Action**: Kernel tuning to close the efficiency gap. Estimated 1.963 ms recoverable.

**Impact**: Up to 1.963 ms savings through kernel tuning.

→ *See Detailed Analysis: Convolution below*

---

## System-Level Optimizations

> **Note:** System-level analysis is exploratory.

✅ No system-level bottlenecks detected. GPU activity breakdown shows 71.8% computation, with negligible memcpy and communication overhead.

---

## Detailed Analysis: Compute Kernels

### 1. Convolution (96.1% of compute)

# Convolution Analysis Findings

**Status**: SUCCESS
**Analysis Tier**: Compute Kernel
**Total Time**: 2.200 ms (69.0% of compute)
**Operation Count**: 1
**Average Efficiency**: 10.8%

## Operations Summary

| Operation | Count | Time (ms) | % of Category | Efficiency (%) | Bound | Compute Spec |
|-----------|-------|-----------|---------------|----------------|-------|-------------|
| aten::convolution | 1 | 2.200 | 100.0% | 10.8 | compute | matrix_fp32 |

## Operation Classification

- **aten::convolution**: Standard 2D Convolution

## Layout Analysis

Transpose overhead: 0.0% — acceptable

## Bottleneck Analysis

### aten::convolution
- **Time**: 2.200 ms (100.0% of category)
- **Efficiency**: 10.8% (compute-bound)
- **TFLOPS achieved**: 17.57
- **TB/s achieved**: 0.03

## Recommendations

### Kernel Tuning: Optimize low-efficiency convolutions
- **aten::convolution**: 10.8% efficiency → potential 1.963 ms savings

## Impact Summary
| Recommendation | Type | Estimated Savings (ms) | Confidence |
|---------------|------|----------------------|------------|
| aten::convolution kernel tuning | kernel_tuning | 1.963 | medium |


---

### 2. elementwise (3.9% of compute)

# Elementwise Analysis Findings

**Status**: SUCCESS
**Total Time**: 0.090 ms (2.8% of compute)
**Average Efficiency**: 2.0%

Elementwise operations are minor (2.8% of compute). No significant optimization opportunity.

## Impact Summary
| Recommendation | Type | Estimated Savings (ms) | Confidence |
|---------------|------|----------------------|------------|


---

## Detailed Analysis: System-Level

## Appendix

### Hardware Reference
- **Platform**: MI300X
- **Peak HBM BW**: 5.3 TB/s
- **Peak MAF (BF16)**: 708 TFLOPS
- **Peak MAF (FP8)**: 1273 TFLOPS

*Generated: 2026-02-25 13:39:16*
