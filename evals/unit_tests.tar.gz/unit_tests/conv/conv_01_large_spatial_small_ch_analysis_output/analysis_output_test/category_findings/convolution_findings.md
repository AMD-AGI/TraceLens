<!--
Copyright (c) 2024 - 2025 Advanced Micro Devices, Inc. All rights reserved.

See LICENSE for license information.
-->

# Convolution category findings

## Overview

**Status:** SUCCESS. Convolution GPU kernel time is **4.5 ms** (100% of this category; matches `metadata/convolution_metadata.json` → `time_breakdown.gpu_kernel_time_ms`). **One** operation row: `aten::convolution` (classified as **Standard 2D** conv2d-style forward; `(source: category_data/conv_fwd_tree_data.json)` input `(1, 3, 2048, 2048)`, weights `(64, 3, 7, 7)`). Roofline classifies the op as **compute-bound** vs **163 TFLOPS** peak MAF for `matrix_fp32` (`resolved_peak_maf`); HBM reference **5.3 TB/s** (`resolved_peak_hbm_bw`) applies if the op were memory-limited. **Transpose overhead:** `category_specific.transpose_overhead_percent` is **0%** — no layout-mismatch signal from attributed transpose time (`source: category_data/convolution_metrics.json`).

## Operations Breakdown

| Operation | Count | Time (ms) | % of Category | Efficiency | FLOPS/Byte | Type |
|-----------|-------|-----------|---------------|------------|------------|------|
| aten::convolution | 1 | 4.5 | 100.0 | 2.69% of 163 TFLOPS | 61.89 | compute-bound |

## Layout and transpose overhead

- **`category_specific.transpose_overhead_percent`:** 0.0% (0 transpose ops, 0 ms in this category).
- **Interpretation:** No elevated transpose overhead; NHWC / `channels_last` is optional for this slice but not indicated by transpose attribution.

## Key bottlenecks

1. **`aten::convolution` (1×, 4.5 ms, 100% of category)** — Meets bottleneck criteria: **> 5% of category time** and **efficiency 2.69%** of peak (**< 70%** threshold) on the **compute** roofline (**163 TFLOPS** `resolved_peak_maf`). Arithmetic intensity **61.89 FLOPS/Byte** supports a compute-bound classification vs the MI300X FP32 matrix peak. Tune kernel / launch configuration and occupancy rather than chasing HBM bandwidth first.

## Impact Summary

| Recommendation | Type | Estimated Savings (ms) | Estimated Improvement (E2E %) | Confidence |
|---------------|------|------------------------|-------------------------------|------------|
| Kernel tuning for `aten::convolution` (compute-bound, 2.69% of 163 TFLOPS peak) | kernel_tuning | 4.339–4.379 | 96.41–97.31% | medium |

## Detailed Analysis

<!-- reasoning-candidate tier=compute rank=1 -->
#### Low roofline utilization on forward `aten::convolution` (compute-bound vs FP32 matrix peak)

**Identification:** The only convolution in this trace is a single forward `aten::convolution` that dominates category GPU kernel time but achieves a small fraction of the FP32 matrix roofline peak `(source: category_data/convolution_metrics.json operations[0], metadata/convolution_metadata.json time_breakdown.gpu_kernel_time_ms)`.

**Data:**

| Operation | Kernel time (ms) | % of category | Count | FLOPS/Byte | Efficiency | Bound |
|-----------|------------------|---------------|-------|------------|------------|-------|
| aten::convolution | 4.5 | 100.0 | 1 | 61.89 | 2.69% of 163 TFLOPS | compute-bound |

**Reasoning for Slowdown:** GPU time is attributed entirely to this conv; roofline efficiency **2.69%** vs **`resolved_peak_maf` 163 TFLOPS** indicates the kernel is far from the compute roofline. Intensity **61.89 FLOPS/Byte** is well above typical memory-bound conv regimes on this peak set, so the limiting factor is treated as compute-side utilization (wave occupancy, tile sizes, or library choice) rather than HBM **`resolved_peak_hbm_bw` 5.3 TB/s**. No efficiency exceeds 100%; nothing flagged as `[ANOMALY] - verify measurement`.

**Resolution:** Focus on **kernel tuning**: try alternative cuDNN / PyTorch algorithms (`torch.backends.cudnn.benchmark`), dtype or layout consistent with library fast paths, and profiler-guided checks for occupancy and register pressure. If later profiling shows memory binding, revisit access patterns; **layout fix** (`model.to(memory_format=torch.channels_last)`) is secondary here because **transpose overhead is 0%** in metrics.

**Impact estimate:**

- Low end (75% roofline target): 4.339 ms savings (96.41% E2E)
- High end (100% roofline target): 4.379 ms savings (97.31% E2E)
- Range: 4.339–4.379 ms (96.41–97.31% E2E)
