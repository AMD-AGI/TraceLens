<!--
Copyright (c) 2024 - 2025 Advanced Micro Devices, Inc. All rights reserved.

See LICENSE for license information.
-->

# Workload - MI300X Standalone Analysis

## Executive Summary

This trace captures a single 1×1 pointwise `aten::convolution` on MI300X with FP32 precision. Input shape [16, 1024, 14, 14], weight [2048, 1024, 1, 1], stride=(1,1). The GPU is 100% utilized with zero idle time. The convolution is compute-bound (FLOPS/Byte = 280.31) but achieves only 13.45% of peak FP32 matrix throughput (21.92 TFLOPS vs 163 TFLOPS peak), indicating significant tuning headroom for this batched-GEMM-equivalent workload.

| Metric | Value |
|--------|-------|
| Total Compute Time | 0.60 ms |
| Computation | 100.0% |
| Idle Time | 0.0% |
| Exposed Communication | 0.0% |
| Top Bottleneck Category | Convolution (100%) |

---

## Compute Kernel Optimizations

Findings from per-category kernel analysis (Convolution).

### Top Operations

| Rank | Category | Time (ms) | % of Compute Time | Ops | Potential improvement (time, E2E %) |
|------|----------|-----------|-------------------|-----|-------------------------------------|
| 1 | Convolution | 0.60 | 100% | 1 | — |

### 🔴 P1: 1×1 Pointwise Convolution — Low FP32 Efficiency (13.45%)

**Insight**: The `aten::convolution` (1×1 pointwise, FP32) achieves 21.92 TFLOPS vs 163 TFLOPS peak matrix FP32 — 13.45% utilization. This 1×1 conv is equivalent to a batched GEMM with M=3136, N=2048, K=1024. The kernel `igemm_fwd_gtcx_nhwc_fp32_bx0_bt256x128x16` may not optimally tile this shape.

**Action**: Investigate tile size optimization for this batched GEMM shape (3136×2048×1024). Consider BF16/FP16 precision if numerically acceptable — peak moves to 708/654 TFLOPS. Fuse with neighboring elementwise ops to reduce launches and memory traffic.

**Impact**: Not quantifiable from trace data (no kernel_tuning estimates available).

→ *See [Detailed Analysis: Compute Kernels > 1. Convolution](#1-convolution-100-of-compute) for details*

---

## System-Level Optimizations

> **Note:** System-level analysis is exploratory. The patterns and recommendations below are under active development and may be refined as system-level analysis matures.

✅ No system-level bottlenecks detected. GPU activity breakdown shows 100% computation, with negligible memcpy and communication overhead. See [Detailed Analysis: System-Level](#detailed-analysis-system-level) for full metrics.

---

## Detailed Analysis: Compute Kernels

### 1. Convolution (100% of compute)

Single 1×1 pointwise convolution consuming 0.6 ms of GPU kernel time. The operation reduces to a batched GEMM and is compute-bound with high arithmetic intensity.

| Operation | Kernel time (ms) | % of category | Count | FLOPS/Byte | Efficiency | Potential improvement (time, E2E %) |
|-----------|-----------------|---------------|-------|------------|------------|-------------------------------------|
| aten::convolution | 0.60 | 100% | 1 | 280.31 | 13.45% of 163 TFLOPS peak (matrix FP32) | — |

**Kernel details**: `igemm_fwd_gtcx_nhwc_fp32_bx0_bt256x128x16` — grid=[512,1,1], block=[256,1,1].

**Workload parameters**:
- Input: [16, 1024, 14, 14], Weight: [2048, 1024, 1, 1], FP32
- Stride=(1,1), Padding=(0,0), Dilation=(1,1), Groups=1
- Equivalent batched GEMM: M=batch×H×W=16×14×14=3136, N=out_ch=2048, K=in_ch=1024
- NHWC layout already in use (0% transpose overhead)

**Key observations**:
- Compute-bound (FLOPS/Byte = 280.31), well above the MI300X ridge point
- Achieved 21.92 TFLOPS vs 163 TFLOPS peak — 13.45% utilization
- HBM bandwidth: 0.08 TB/s vs 5.3 TB/s peak (1.5%) — expected for compute-bound workload
- The 256×128×16 tile configuration may not fully exploit the 3136 rows or 2048 columns of the equivalent GEMM

---

## Detailed Analysis: System-Level

> **Note:** System-level analysis is exploratory. The patterns and recommendations below are under active development and may be refined as system-level analysis matures.

<a id="cpu-idle-time-analysis"></a>
### 1. CPU/Idle Time Analysis

GPU idle time is 0.0%, well below the 15% threshold. No action required.

| Metric | Value |
|--------|-------|
| Total GPU Time | 0.60 ms |
| Computation | 100.0% |
| Idle | 0.0% |
| Communication | 0.0% |
| MemCpy | 0.0% |

CPU duration (0.8 ms) modestly exceeds GPU kernel time (0.6 ms) with a ratio of 1.33×. No sync bottleneck detected.

<a id="multi-kernel-issues"></a>
### 2. Multi-Kernel Issues

No multi-kernel issues detected. Zero memcpy transfers and zero NCCL collective operations were observed. Communication/compute overlap is not applicable.

---

## Appendix

### Model Architecture
- **Model**: Cannot be inferred from trace
- **Architecture**: Cannot be inferred from trace
- **Scale**: Cannot be inferred from trace
- **Precision**: FP32

### Hardware Reference
- **Platform**: MI300X
- **Peak HBM BW**: 5.3 TB/s
- **Peak MAF (FP32)**: 163 TFLOPS
- **Peak MAF (BF16)**: 708 TFLOPS
- **Peak MAF (FP16)**: 654 TFLOPS
- **Peak MAF (FP8)**: 1273 TFLOPS
