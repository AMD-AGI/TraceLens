# SDPA Forward Pass Findings

## Summary

| Metric | Value |
|--------|-------|
| **Attention Type** | Flash Attention |
| **Total Category Time** | 3.2 ms |
| **Percent of Compute** | 100.0% |
| **Operation Count** | 1 |
| **Average Efficiency** | 6.07% |
| **Peak MAF (BF16)** | 708 TFLOPS |
| **Peak HBM BW** | 5.3 TB/s |

**Key Finding:** The single SDPA operation achieves only **6.07%** of peak compute efficiency despite using Flash Attention. The large head dimension (d_h=256) is a likely contributor, as Flash Attention kernels are typically optimized for d_h=64 and d_h=128.

---

## Operation Analysis

### aten::_scaled_dot_product_flash_attention

| Attribute | Value |
|----------|-------|
| **Time** | 3.2 ms |
| **Percent of Category** | 100.0% |
| **TFLOPS Achieved** | 42.95 |
| **TB/s Achieved** | 0.04 |
| **Efficiency** | 6.07% |
| **Bound Type** | Compute |
| **FLOPS/Byte** | 1024.0 |

**Input Dimensions:** `((4, 8, 2048, 256), (4, 8, 2048, 256), (4, 8, 2048, 256))`

**Performance Parameters:**
- Batch size (B): 4
- Query sequence length (N_Q): 2048
- KV sequence length (N_KV): 2048
- Query heads (H_Q): 8
- KV heads (H_KV): 8
- Head dimension (d_h_qk, d_h_v): 256
- Dropout: 0.0
- Causal: False
- Flash implementation: True

**Kernel:** `flash_fwd_kernel_bf16_hdim256` (3200 µs)

**Attention Pattern:** MHA (Multi-Head Attention) — H_Q == H_KV = 8

---

## Efficiency Context

| Sequence Length | Expected Efficiency (Standard) | Actual |
|-----------------|-------------------------------|--------|
| N = 2048 | 40–60% | **6.07%** |

For N=2048, Flash Attention typically achieves 40–60% of peak on well-tuned kernels. The observed 6.07% is far below this range.

---

## Root Cause Analysis

### 1. Large Head Dimension (d_h=256)

- **Standard head dims:** 64, 128
- **Observed:** 256
- Flash Attention implementations are usually tuned for d_h=64 and d_h=128. At d_h=256:
  - Tile sizes and register usage may be suboptimal
  - Memory access patterns may be less efficient
  - Warp occupancy and shared memory layout may not match the kernel design

### 2. Compute-Bound Behavior

- **FLOPS/Byte = 1024.0** — strongly compute-bound
- **Bound type:** Compute
- The kernel is limited by compute, not memory bandwidth, so the low efficiency reflects underutilization of compute units rather than memory bottlenecks.

### 3. Kernel-Specific Behavior

- Kernel `flash_fwd_kernel_bf16_hdim256` is specialized for d_h=256
- It may be a fallback or less-optimized path compared to the standard d_h=64/128 kernels

---

## Optimization Recommendations

### 1. Kernel Tuning (Primary)

**Action:** Profile and optimize `flash_fwd_kernel_bf16_hdim256` for MI300X.

**Focus areas:**
- Tile sizes for d_h=256
- Shared memory and register allocation
- Warp-level parallelism and occupancy
- Vectorization for BF16 at head dim 256

**Expected impact:** Up to ~3.0 ms savings (from current 3.2 ms) if efficiency approaches 40–50%.

### 2. Algorithmic: Model Architecture Review

**Action:** Evaluate whether d_h=256 is required for the model.

- If the architecture allows, consider **Grouped Query Attention (GQA)** to reduce effective head dimension per KV head
- Some models use d_h=256 for specific layers; confirm if this is necessary or can be adjusted

### 3. Batch Size and Sequence Length

**Action:** If possible, increase batch size (B=4 → 8 or 16) to improve GPU utilization.

- Larger batches can amortize kernel launch and improve occupancy
- Sequence length N=2048 is reasonable; no change needed there

---

## Impact Summary

| Recommendation | Type | Estimated Savings (ms) | Confidence |
|----------------|------|------------------------|------------|
| Optimize flash_fwd_kernel_bf16_hdim256 for d_h=256 | kernel_tuning | 3.0 | medium |
| Review model architecture for d_h=256 necessity | algorithmic | TBD | low |
| Increase batch size if feasible | algorithmic | 0.5–1.0 | low |

**Note:** The kernel_tuning estimate (3.0 ms) is derived from `savings_ms = time_ms × (1 - efficiency_pct/100)` = 3.2 × (1 - 6.07/100) ≈ 3.006 ms. Confidence is medium because the gap to expected efficiency is clear, but the achievable gain depends on kernel implementation and hardware specifics.
