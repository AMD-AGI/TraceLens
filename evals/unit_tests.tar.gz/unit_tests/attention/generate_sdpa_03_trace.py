#!/usr/bin/env python3
"""
Generate sdpa_03 (short sequence overhead) trace by transforming sdpa_01 trace.
Transforms [1, 32, 32768, 128] -> [16, 32, 128, 128], scales GPU kernel durations,
and adjusts timestamps for the overhead pattern (CPU time dominates).
"""

import json
import random
import re
import sys
from pathlib import Path


# Dimension and stride mappings
DIMS_01 = [1, 32, 32768, 128]
DIMS_03 = [16, 32, 128, 128]
STRIDES_01 = [134217728, 4194304, 128, 1]
STRIDES_03 = [524288, 16384, 128, 1]
STRIDES_TRANSPOSED_01 = [134217728, 128, 4194304, 1]
STRIDES_TRANSPOSED_03 = [524288, 128, 16384, 1]
DIMS_TRANSPOSED_01 = [1, 32768, 32, 128]
DIMS_TRANSPOSED_03 = [16, 128, 32, 128]

# GPU kernel scaling: original ~54-86 ms -> new 80-150 us
GPU_DUR_MIN = 80
GPU_DUR_MAX = 150
GPU_GAP_MIN = 20
GPU_GAP_MAX = 50

# Total trace span for sdpa_03 (~2.5 ms)
NEW_TRACE_SPAN_US = 2500
BASE_TS = 5888649824010.946

# Seed for reproducibility
random.seed(42)


def replace_dims_strides(obj):
    """Recursively replace dimensions and strides in JSON-serializable object."""
    if isinstance(obj, list):
        result = []
        for item in obj:
            result.append(replace_dims_strides(item))
        return result
    elif isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            result[k] = replace_dims_strides(v)
        return result
    elif isinstance(obj, (int, float)):
        return obj
    elif isinstance(obj, str):
        # Replace in string representations
        s = obj
        # [1, 32, 32768, 128] -> [16, 32, 128, 128]
        s = re.sub(r'\[1,\s*32,\s*32768,\s*128\]', '[16, 32, 128, 128]', s)
        # [1, 32768, 32, 128] -> [16, 128, 32, 128]
        s = re.sub(r'\[1,\s*32768,\s*32,\s*128\]', '[16, 128, 32, 128]', s)
        # [32, 32768] -> [32, 128] (empty ops softmax lse)
        s = re.sub(r'\[32,\s*32768\]', '[32, 128]', s)
        # [1, 32, 32768] -> [16, 32, 128] (view ops)
        s = re.sub(r'\[1,\s*32,\s*32768\]', '[16, 32, 128]', s)
        # "32768" as seq_len in Concrete Inputs (indices 5, 6 for _flash_attention_forward)
        # Be careful: only replace in Concrete Inputs context for seq_len
        return s
    else:
        return obj


def transform_value(val, key_path=""):
    """Transform a single value (list of numbers) for dims/strides."""
    if not isinstance(val, list):
        return val
    if len(val) == 4:
        if val == DIMS_01:
            return DIMS_03.copy()
        if val == DIMS_TRANSPOSED_01:
            return DIMS_TRANSPOSED_03.copy()
        if val == STRIDES_01:
            return STRIDES_03.copy()
        if val == STRIDES_TRANSPOSED_01:
            return STRIDES_TRANSPOSED_03.copy()
    return val


def transform_args(args, op_name=""):
    """Transform args dict - dims, strides, Concrete Inputs."""
    if not isinstance(args, dict):
        return args
    result = dict(args)

    for key in ["Input Dims", "Input Strides", "Output Dims", "Output Strides"]:
        if key in result and isinstance(result[key], list):
            new_list = []
            for item in result[key]:
                if isinstance(item, list):
                    new_list.append(transform_value(item))
                else:
                    new_list.append(item)
            result[key] = new_list

    # Concrete Inputs: replace "32768" with "128" for seq_len (indices 5, 6) in _flash_attention_forward
    if "Concrete Inputs" in result and op_name == "aten::_flash_attention_forward":
        ci = result["Concrete Inputs"]
        if isinstance(ci, list) and len(ci) >= 7:
            ci = list(ci)
            if ci[5] == "32768":
                ci[5] = "128"
            if ci[6] == "32768":
                ci[6] = "128"
            result["Concrete Inputs"] = ci

    # empty_strided / empty Concrete Inputs with [1, 32768, 32, 128] or [32, 32768]
    if "Concrete Inputs" in result:
        ci = result["Concrete Inputs"]
        if isinstance(ci, list):
            ci = list(ci)
            for i, v in enumerate(ci):
                if isinstance(v, str):
                    v = v.replace("[1, 32768, 32, 128]", "[16, 128, 32, 128]")
                    v = v.replace("[32, 32768]", "[32, 128]")
                    v = v.replace("[1, 32, 32768]", "[16, 32, 128]")
                    ci[i] = v
            result["Concrete Inputs"] = ci

    return result


def deep_transform(obj, op_name=""):
    """Deep transform for nested structures with proper list handling."""
    if isinstance(obj, list):
        if len(obj) == 4 and all(isinstance(x, (int, float)) for x in obj):
            return transform_value(obj)
        return [deep_transform(x, op_name) for x in obj]
    elif isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            if k == "args" and "name" in obj:
                result[k] = transform_args(v, obj.get("name", ""))
            else:
                result[k] = deep_transform(v, op_name)
        return result
    else:
        return obj


def main():
    input_path = Path("/home/ahasssan/TraceLens-internal/evals/unit_tests/attention/sdpa_01_long_seq_low_eff_analysis_output/sdpa_01_long_seq_low_eff.json")
    output_path = Path("/home/ahasssan/TraceLens-internal/evals/unit_tests/attention/sdpa_03_short_seq_overhead_analysis_output/sdpa_03_short_seq_overhead.json")

    with open(input_path) as f:
        data = json.load(f)

    # Build mapping: External id -> _flash_attention_forward (ts, dur)
    flash_attn_ops = {}
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "aten::_flash_attention_forward" and ev.get("ph") == "X":
            args = ev.get("args", {})
            ext_id = args.get("External id")
            if ext_id is not None:
                flash_attn_ops[ext_id] = {"ts": ev["ts"], "dur": ev["dur"]}

    # Collect hipModuleLaunchKernel events with their External id and correlation
    launch_events = []
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipModuleLaunchKernel" and ev.get("cat") == "cuda_runtime":
            args = ev.get("args", {})
            ext_id = args.get("External id")
            corr = args.get("correlation")
            if ext_id is not None and corr is not None:
                launch_events.append({
                    "ev": ev,
                    "ext_id": ext_id,
                    "correlation": corr,
                    "idx": len(launch_events),
                })

    # Collect attn_fwd.kd GPU kernels (ordered by correlation)
    gpu_kernels = []
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "attn_fwd.kd" and ev.get("cat") == "kernel":
            args = ev.get("args", {})
            corr = args.get("correlation")
            if corr is not None:
                gpu_kernels.append({"ev": ev, "correlation": corr})

    # Sort GPU kernels by correlation to match launch order
    corr_to_launch_idx = {le["correlation"]: le["idx"] for le in launch_events}
    gpu_kernels.sort(key=lambda k: corr_to_launch_idx.get(k["correlation"], 999))

    # Generate new GPU kernel durations (80-150 us)
    new_gpu_durs = [random.uniform(GPU_DUR_MIN, GPU_DUR_MAX) for _ in gpu_kernels]
    new_gpu_gaps = [random.uniform(GPU_GAP_MIN, GPU_GAP_MAX) for _ in range(len(gpu_kernels) - 1)]

    # First GPU kernel starts at base + 500 us (after initial CPU ops)
    gpu_start_offset = 500
    new_gpu_ts = []
    t = gpu_start_offset
    for i, dur in enumerate(new_gpu_durs):
        new_gpu_ts.append(BASE_TS + t)
        t += dur
        if i < len(new_gpu_gaps):
            t += new_gpu_gaps[i]

    total_gpu_time_us = t - gpu_start_offset

    # Apply dimension/stride transformations to all events
    data = deep_transform(data)

    # Compress CPU timeline: events before sync (ts < first_sync_ts) get scaled
    first_sync_ts = 5888649824824.357
    second_sync_ts = 5888650482985.051
    cpu_range_end = first_sync_ts
    cpu_range_start = BASE_TS
    cpu_scale = 400.0 / (cpu_range_end - cpu_range_start)  # Map to 400 us

    for ev in data.get("traceEvents", []):
        ts = ev.get("ts")
        dur = ev.get("dur")
        if ts is None:
            continue
        # Scale CPU and cuda_runtime events (before sync)
        if ev.get("pid") == 51105 and ts < first_sync_ts:
            ev["ts"] = BASE_TS + (ts - cpu_range_start) * cpu_scale
            if dur is not None and dur > 0:
                ev["dur"] = dur * cpu_scale
        # Events between syncs (e.g. GPU) - already updated
        # Events after second sync - place at end of new timeline
        elif ev.get("pid") == 51105 and ts > second_sync_ts:
            ev["ts"] = BASE_TS + 400 + total_gpu_time_us + 10

    # Update traceName
    data["traceName"] = "/home/ahasssan/TraceLens-internal/evals/unit_tests/attention/sdpa_03_short_seq_overhead_analysis_output/sdpa_03_short_seq_overhead.json"

    # Update GPU kernel events
    transformed_kernels = [
        ev for ev in data.get("traceEvents", [])
        if ev.get("name") == "attn_fwd.kd" and ev.get("cat") == "kernel"
    ]
    transformed_kernels.sort(key=lambda e: corr_to_launch_idx.get(e.get("args", {}).get("correlation"), 999))
    for i, ev in enumerate(transformed_kernels):
        if i < len(new_gpu_ts) and i < len(new_gpu_durs):
            ev["ts"] = new_gpu_ts[i]
            ev["dur"] = new_gpu_durs[i]

    # Rebuild flash_attn_ops from the COMPRESSED data (post CPU timeline scaling)
    flash_attn_ops_compressed = {}
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "aten::_flash_attention_forward" and ev.get("ph") == "X":
            args = ev.get("args", {})
            ext_id = args.get("External id")
            if ext_id is not None:
                flash_attn_ops_compressed[ext_id] = {"ts": ev["ts"], "dur": ev["dur"]}

    # Position ALL cuda_runtime events within their parent _flash_attention_forward
    ext_id_to_events = {}
    for ev in data.get("traceEvents", []):
        if ev.get("cat") != "cuda_runtime":
            continue
        args = ev.get("args") or {}
        ext_id = args.get("External id")
        if ext_id is None:
            continue
        if ext_id not in ext_id_to_events:
            ext_id_to_events[ext_id] = []
        ext_id_to_events[ext_id].append(ev)

    for ext_id, events in ext_id_to_events.items():
        if ext_id not in flash_attn_ops_compressed:
            continue
        parent = flash_attn_ops_compressed[ext_id]
        events.sort(key=lambda e: (0 if e.get("name") == "hipStreamGetDevice" else 1, e.get("ts", 0)))
        avail = parent["dur"] * 0.9
        step = max(0.5, avail / max(1, len(events)))
        for i, ev in enumerate(events):
            ev["ts"] = parent["ts"] + 1 + i * step
            if ev.get("dur", 0) > step * 0.8:
                ev["dur"] = step * 0.6

    # Update hipDeviceSynchronize
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipDeviceSynchronize" and ev.get("cat") == "cuda_runtime":
            if ev.get("dur", 0) > 100:
                ev["ts"] = BASE_TS + 400
                ev["dur"] = total_gpu_time_us + 50

    sync_events = [e for e in data["traceEvents"] if e.get("name") == "hipDeviceSynchronize"]
    if len(sync_events) >= 2:
        first = sync_events[0]
        second = sync_events[1]
        if first["dur"] > 100:
            second["ts"] = first["ts"] + first["dur"]

    # Update ac2g flow events
    corr_to_launch_ts = {}
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipModuleLaunchKernel" and ev.get("cat") == "cuda_runtime":
            corr = ev.get("args", {}).get("correlation")
            if corr is not None:
                corr_to_launch_ts[corr] = ev["ts"]
    corr_to_gpu_ts = {}
    for i, gk in enumerate(gpu_kernels):
        corr_to_gpu_ts[gk["correlation"]] = new_gpu_ts[i]

    # Also build map for hipStreamGetDevice correlation -> ts
    corr_to_hsgd_ts = {}
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipStreamGetDevice" and ev.get("cat") == "cuda_runtime":
            corr = ev.get("args", {}).get("correlation")
            if corr is not None:
                corr_to_hsgd_ts[corr] = ev["ts"]

    for ev in data.get("traceEvents", []):
        if ev.get("cat") == "ac2g" and ev.get("name") == "ac2g":
            ev_id = ev.get("id")
            if ev_id is None:
                continue
            if ev.get("ph") == "s" and ev.get("pid") == 51105:
                if ev_id in corr_to_launch_ts:
                    ev["ts"] = corr_to_launch_ts[ev_id]
            elif ev.get("ph") == "f" and ev.get("pid") == 0:
                if ev_id in corr_to_gpu_ts:
                    ev["ts"] = corr_to_gpu_ts[ev_id]
            elif ev.get("ph") == "f" and ev.get("pid") == 51105:
                if ev_id in corr_to_hsgd_ts:
                    ev["ts"] = corr_to_hsgd_ts[ev_id]

    # Update PyTorch Profiler span
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "PyTorch Profiler (0)" and ev.get("tid") == "PyTorch Profiler":
            ev["ts"] = BASE_TS
            ev["dur"] = NEW_TRACE_SPAN_US

    for ev in data.get("traceEvents", []):
        if ev.get("name") == "Record Window End":
            ev["ts"] = BASE_TS + NEW_TRACE_SPAN_US

    for ev in data.get("traceEvents", []):
        if ev.get("name") == "Iteration Start: PyTorch Profiler":
            ev["ts"] = BASE_TS

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(data, f, indent=2)

    print(f"Generated {output_path}")
    print(f"  GPU kernels: {len(gpu_kernels)} kernels, total GPU time ~{total_gpu_time_us:.0f} us")
    print(f"  Trace span: {NEW_TRACE_SPAN_US} us")


if __name__ == "__main__":
    main()
