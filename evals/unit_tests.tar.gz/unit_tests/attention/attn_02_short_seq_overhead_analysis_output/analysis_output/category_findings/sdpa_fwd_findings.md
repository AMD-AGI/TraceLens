# SDPA Forward Analysis Findings

## Status: OK

## Attention Type Detected

| Type | Detected | Count |
|------|----------|-------|
| **Flash Attention** | Yes | 1 |
| **Paged Attention** | No | 0 |

The trace uses **Flash Attention** (PyTorch SDPA backend). No unfused attention patterns were detected.

---

## Summary

| Metric | Value |
|--------|-------|
| Total SDPA time | 0.025 ms |
| Percent of compute | 100.0% |
| Operation count | 1 |
| Average efficiency | 0.76% |
| Peak MAF (BF16) | 708 TFLOPS |
| Peak HBM BW | 5.3 TB/s |

---

## Operations Table

| Operation | Time (ms) | % of Category | Efficiency | Bound | Input Dims | Attention Pattern |
|-----------|-----------|---------------|------------|-------|------------|-------------------|
| aten::_scaled_dot_product_flash_attention | 0.025 | 100.0% | 0.76% | compute | (32, 32, 16, 128) × 3 | MHA |

**Perf params:** B=32, N_Q=16, H_Q=32, N_KV=16, H_KV=32, d_h_qk=128, d_h_v=128, causal=False, flash_impl=True

---

## Bottleneck Analysis

### Primary Bottleneck: Short Sequence Length + Launch Overhead

The single SDPA operation exhibits **extremely low efficiency (0.76%)** despite using Flash Attention. Two factors drive this:

1. **Very short sequence length (N_Q=16, N_KV=16)**  
   For N < 512, expected efficiency is typically 5–15% due to memory overhead. At N=16, the workload is heavily memory-bound and underutilizes the GPU.

2. **CPU launch overhead dominates**  
   - GPU kernel duration: **25 µs**  
   - CPU duration: **225 µs** (9× the GPU time)  
   The framework spends far more time launching and coordinating the kernel than the kernel spends executing.

### Efficiency Context

| Sequence Length | Expected Efficiency | Actual |
|-----------------|---------------------|--------|
| N < 512 | 5–15% | 0.76% |

Efficiency is below the expected range for short sequences, indicating both inherent workload limits and possible launch overhead.

### Kernel Details

- **Kernel:** `flash_fwd_kernel_bf16`
- **Achieved:** 5.37 TFLOPS / 0.67 TB/s
- **Peak:** 708 TFLOPS / 5.3 TB/s
- **Bound type:** Compute (FLOPS/Byte = 8.0)

---

## Recommendations

### Algorithmic (Workload / Configuration)

| Recommendation | Rationale |
|----------------|-----------|
| **Increase sequence length** | N=16 is too short for efficient attention. Batching more tokens or using longer sequences (e.g., N ≥ 512) would improve utilization. |
| **Batch more tokens per forward pass** | With B=32 and N=16, total tokens = 512. Larger effective batch (e.g., via chunked prefill or higher batch size) can amortize launch overhead. |
| **Profile with representative workload** | 0.025 ms total GPU time suggests a micro-benchmark or single-layer trace. Profile full-model inference with realistic sequence lengths. |

### Kernel-Level

| Recommendation | Rationale |
|----------------|-----------|
| **Investigate CPU launch overhead** | CPU time (225 µs) is 9× GPU time (25 µs). Consider kernel fusion or batching to reduce launch frequency. |
| **Replay artifact (optional)** | For deeper kernel tuning, generate a replay artifact. Gains will be limited by the short sequence length. |

### Note on Impact

Total SDPA time is **0.025 ms**. Even large relative improvements yield small absolute savings. The main value is understanding behavior for short-sequence workloads and launch overhead.

---

## Impact Summary

| Recommendation | Type | Estimated Savings (ms) | Confidence |
|----------------|------|------------------------|------------|
| Increase sequence length / batch more tokens | algorithmic | N/A (workload-dependent) | medium |
| Reduce CPU launch overhead via batching/fusion | algorithmic | ~0.2 (CPU-side) | low |
| Kernel tuning (replay artifact) | kernel_tuning | < 0.02 | low |

**Note:** Savings are small because total SDPA time is 0.025 ms. Focus on workload design and launch overhead rather than kernel micro-optimization.
