#!/usr/bin/env python3
"""
Generate sdpa_04 (large head dim) trace by transforming sdpa_01 trace.
Transforms [1, 32, 32768, 128] -> [1, 32, 4096, 256], scales GPU kernel durations
to reflect moderate efficiency with the non-standard 256 head dimension (requires
multiple tile passes in Flash Attention, reducing throughput).
"""

import json
import random
import re
import sys
from pathlib import Path


# Dimension and stride mappings
# Original sdpa_01: batch=1, heads=32, seq=32768, head_dim=128
DIMS_01 = [1, 32, 32768, 128]
DIMS_04 = [1, 32, 4096, 256]
STRIDES_01 = [134217728, 4194304, 128, 1]
# New strides: [32*4096*256, 4096*256, 256, 1]
STRIDES_04 = [33554432, 1048576, 256, 1]

# Transposed layouts (seq and heads swapped)
DIMS_TRANSPOSED_01 = [1, 32768, 32, 128]
DIMS_TRANSPOSED_04 = [1, 4096, 32, 256]
STRIDES_TRANSPOSED_01 = [134217728, 128, 4194304, 1]
STRIDES_TRANSPOSED_04 = [33554432, 256, 1048576, 1]

# GPU kernel scaling: original ~54-86 ms -> new 5-10 ms
# (4096 seq with 256 head_dim, efficiency ~40-55% due to non-standard head_dim)
GPU_DUR_MIN = 5000
GPU_DUR_MAX = 10000
GPU_GAP_MIN = 50
GPU_GAP_MAX = 200

# Total trace span for sdpa_04 (~120 ms covering all 10 kernels)
NEW_TRACE_SPAN_US = 120000
BASE_TS = 5888649824010.946

# Scale factor for softmax LSE dims
SEQ_01 = 32768
SEQ_04 = 4096
HEAD_DIM_01 = 128
HEAD_DIM_04 = 256
SCALE_04 = 1.0 / (HEAD_DIM_04 ** 0.5)  # 0.0625

random.seed(44)


def transform_value(val):
    """Transform a single value (list of numbers) for dims/strides."""
    if not isinstance(val, list) or len(val) != 4:
        return val
    if not all(isinstance(x, (int, float)) for x in val):
        return val
    if val == DIMS_01:
        return DIMS_04[:]
    if val == DIMS_TRANSPOSED_01:
        return DIMS_TRANSPOSED_04[:]
    if val == STRIDES_01:
        return STRIDES_04[:]
    if val == STRIDES_TRANSPOSED_01:
        return STRIDES_TRANSPOSED_04[:]
    return val


def transform_args(args, op_name=""):
    """Transform args dict - dims, strides, Concrete Inputs."""
    if not isinstance(args, dict):
        return args
    result = dict(args)

    for key in ["Input Dims", "Input Strides", "Output Dims", "Output Strides"]:
        if key in result and isinstance(result[key], list):
            result[key] = [transform_value(item) if isinstance(item, list) else item
                           for item in result[key]]

    if "Concrete Inputs" in result and op_name == "aten::_flash_attention_forward":
        ci = result["Concrete Inputs"]
        if isinstance(ci, list) and len(ci) >= 7:
            ci = list(ci)
            if ci[5] == str(SEQ_01):
                ci[5] = str(SEQ_04)
            if ci[6] == str(SEQ_01):
                ci[6] = str(SEQ_04)
            # Update scale factor (index 10) from 0.088388... (1/sqrt(128)) to 0.0625 (1/sqrt(256))
            if len(ci) > 10 and "0.088388" in str(ci[10]):
                ci[10] = str(SCALE_04)
            result["Concrete Inputs"] = ci

    if "Concrete Inputs" in result and op_name == "aten::_scaled_dot_product_flash_attention":
        ci = result["Concrete Inputs"]
        if isinstance(ci, list):
            ci = list(ci)
            for i, v in enumerate(ci):
                if isinstance(v, str) and "0.088388" in v:
                    ci[i] = str(SCALE_04)
            result["Concrete Inputs"] = ci

    if "Concrete Inputs" in result:
        ci = result["Concrete Inputs"]
        if isinstance(ci, list):
            ci = list(ci)
            for i, v in enumerate(ci):
                if isinstance(v, str):
                    v = v.replace("[1, 32768, 32, 128]", "[1, 4096, 32, 256]")
                    v = v.replace("[32, 32768]", "[32, 4096]")
                    v = v.replace("[1, 32, 32768]", "[1, 32, 4096]")
                    ci[i] = v
            result["Concrete Inputs"] = ci

    return result


def deep_transform(obj, op_name=""):
    """Deep transform for nested structures."""
    if isinstance(obj, list):
        if len(obj) == 4 and all(isinstance(x, (int, float)) for x in obj):
            return transform_value(obj)
        return [deep_transform(x, op_name) for x in obj]
    elif isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            if k == "args" and "name" in obj:
                result[k] = transform_args(v, obj.get("name", ""))
            else:
                result[k] = deep_transform(v, op_name)
        return result
    elif isinstance(obj, str):
        s = obj
        s = re.sub(r'\[1,\s*32,\s*32768,\s*128\]', '[1, 32, 4096, 256]', s)
        s = re.sub(r'\[1,\s*32768,\s*32,\s*128\]', '[1, 4096, 32, 256]', s)
        s = re.sub(r'\[32,\s*32768\]', '[32, 4096]', s)
        s = re.sub(r'\[1,\s*32,\s*32768\]', '[1, 32, 4096]', s)
        return s
    else:
        return obj


def main():
    input_path = Path("/home/ahasssan/TraceLens-internal/evals/unit_tests/attention/"
                      "sdpa_01_long_seq_low_eff_analysis_output/sdpa_01_long_seq_low_eff.json")
    output_dir = Path("/home/ahasssan/TraceLens-internal/evals/unit_tests/attention/"
                      "sdpa_04_large_head_dim_analysis_output")
    output_path = output_dir / "sdpa_04_large_head_dim.json"

    with open(input_path) as f:
        data = json.load(f)

    # Collect GPU kernels with correlation IDs
    gpu_kernels = []
    corr_to_launch_idx = {}
    launch_idx = 0
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipModuleLaunchKernel" and ev.get("cat") == "cuda_runtime":
            corr = ev.get("args", {}).get("correlation")
            if corr is not None:
                corr_to_launch_idx[corr] = launch_idx
                launch_idx += 1

    for ev in data.get("traceEvents", []):
        if ev.get("name") == "attn_fwd.kd" and ev.get("cat") == "kernel":
            corr = ev.get("args", {}).get("correlation")
            if corr is not None:
                gpu_kernels.append({"ev": ev, "correlation": corr})

    gpu_kernels.sort(key=lambda k: corr_to_launch_idx.get(k["correlation"], 999))

    new_gpu_durs = [random.uniform(GPU_DUR_MIN, GPU_DUR_MAX) for _ in gpu_kernels]
    new_gpu_gaps = [random.uniform(GPU_GAP_MIN, GPU_GAP_MAX) for _ in range(len(gpu_kernels) - 1)]

    gpu_start_offset = 1000
    new_gpu_ts = []
    t = gpu_start_offset
    for i, dur in enumerate(new_gpu_durs):
        new_gpu_ts.append(BASE_TS + t)
        t += dur
        if i < len(new_gpu_gaps):
            t += new_gpu_gaps[i]

    total_gpu_time_us = t - gpu_start_offset

    # Apply dimension/stride transformations
    data = deep_transform(data)

    # Scale CPU timeline
    first_sync_ts = 5888649824824.357
    cpu_range_start = BASE_TS
    cpu_scale = 800.0 / (first_sync_ts - cpu_range_start)

    for ev in data.get("traceEvents", []):
        ts = ev.get("ts")
        dur = ev.get("dur")
        if ts is None:
            continue
        if ev.get("pid") == 51105 and ts < first_sync_ts:
            ev["ts"] = BASE_TS + (ts - cpu_range_start) * cpu_scale
            if dur is not None and dur > 0:
                ev["dur"] = dur * cpu_scale

    # Update traceName
    data["traceName"] = str(output_path)

    # Update GPU kernel events
    transformed_kernels = [
        ev for ev in data.get("traceEvents", [])
        if ev.get("name") == "attn_fwd.kd" and ev.get("cat") == "kernel"
    ]
    transformed_kernels.sort(
        key=lambda e: corr_to_launch_idx.get(e.get("args", {}).get("correlation"), 999))
    for i, ev in enumerate(transformed_kernels):
        if i < len(new_gpu_ts) and i < len(new_gpu_durs):
            ev["ts"] = new_gpu_ts[i]
            ev["dur"] = new_gpu_durs[i]

    # Rebuild flash_attn_ops from compressed data
    flash_attn_ops_compressed = {}
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "aten::_flash_attention_forward" and ev.get("ph") == "X":
            ext_id = ev.get("args", {}).get("External id")
            if ext_id is not None:
                flash_attn_ops_compressed[ext_id] = {"ts": ev["ts"], "dur": ev["dur"]}

    # Position cuda_runtime events within parents
    ext_id_to_events = {}
    for ev in data.get("traceEvents", []):
        if ev.get("cat") != "cuda_runtime":
            continue
        ext_id = (ev.get("args") or {}).get("External id")
        if ext_id is None:
            continue
        ext_id_to_events.setdefault(ext_id, []).append(ev)

    for ext_id, events in ext_id_to_events.items():
        if ext_id not in flash_attn_ops_compressed:
            continue
        parent = flash_attn_ops_compressed[ext_id]
        events.sort(key=lambda e: (0 if e.get("name") == "hipStreamGetDevice" else 1,
                                   e.get("ts", 0)))
        avail = parent["dur"] * 0.9
        step = max(0.5, avail / max(1, len(events)))
        for i, ev in enumerate(events):
            ev["ts"] = parent["ts"] + 1 + i * step
            if ev.get("dur", 0) > step * 0.8:
                ev["dur"] = step * 0.6

    # Update hipDeviceSynchronize
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipDeviceSynchronize" and ev.get("cat") == "cuda_runtime":
            if ev.get("dur", 0) > 100:
                ev["ts"] = BASE_TS + 800
                ev["dur"] = total_gpu_time_us + 100

    sync_events = [e for e in data["traceEvents"] if e.get("name") == "hipDeviceSynchronize"]
    if len(sync_events) >= 2:
        first = sync_events[0]
        second = sync_events[1]
        if first["dur"] > 100:
            second["ts"] = first["ts"] + first["dur"]

    # Update ac2g flow events
    corr_to_launch_ts = {}
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipModuleLaunchKernel" and ev.get("cat") == "cuda_runtime":
            corr = ev.get("args", {}).get("correlation")
            if corr is not None:
                corr_to_launch_ts[corr] = ev["ts"]

    corr_to_gpu_ts = {}
    for i, gk in enumerate(gpu_kernels):
        corr_to_gpu_ts[gk["correlation"]] = new_gpu_ts[i]

    corr_to_hsgd_ts = {}
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "hipStreamGetDevice" and ev.get("cat") == "cuda_runtime":
            corr = ev.get("args", {}).get("correlation")
            if corr is not None:
                corr_to_hsgd_ts[corr] = ev["ts"]

    for ev in data.get("traceEvents", []):
        if ev.get("cat") == "ac2g" and ev.get("name") == "ac2g":
            ev_id = ev.get("id")
            if ev_id is None:
                continue
            if ev.get("ph") == "s" and ev.get("pid") == 51105:
                if ev_id in corr_to_launch_ts:
                    ev["ts"] = corr_to_launch_ts[ev_id]
            elif ev.get("ph") == "f" and ev.get("pid") == 0:
                if ev_id in corr_to_gpu_ts:
                    ev["ts"] = corr_to_gpu_ts[ev_id]
            elif ev.get("ph") == "f" and ev.get("pid") == 51105:
                if ev_id in corr_to_hsgd_ts:
                    ev["ts"] = corr_to_hsgd_ts[ev_id]

    # Update profiler span
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "PyTorch Profiler (0)" and ev.get("tid") == "PyTorch Profiler":
            ev["ts"] = BASE_TS
            ev["dur"] = NEW_TRACE_SPAN_US
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "Record Window End":
            ev["ts"] = BASE_TS + NEW_TRACE_SPAN_US
    for ev in data.get("traceEvents", []):
        if ev.get("name") == "Iteration Start: PyTorch Profiler":
            ev["ts"] = BASE_TS

    # Events after second sync - place at end of new timeline
    second_sync_ts = 5888650482985.051
    for ev in data.get("traceEvents", []):
        ts = ev.get("ts")
        if ts is not None and ev.get("pid") == 51105 and ts > second_sync_ts:
            ev["ts"] = BASE_TS + 800 + total_gpu_time_us + 200

    output_dir.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(data, f, indent=2)

    print("Generated {}".format(output_path))
    print("  GPU kernels: {} kernels, total GPU time ~{:.0f} us".format(
        len(gpu_kernels), total_gpu_time_us))
    print("  Trace span: {} us".format(NEW_TRACE_SPAN_US))


if __name__ == "__main__":
    main()
