<!--
Copyright (c) 2024 - 2025 Advanced Micro Devices, Inc. All rights reserved.

See LICENSE for license information.
-->

# Workload - MI300X Standalone Analysis

## Executive Summary

This trace captures 10 invocations of `aten::_scaled_dot_product_flash_attention` with long sequences (N=32768) on MI300X in BF16 precision. The GPU is fully utilized (~100% computation, ~0% idle) with no communication or memcpy overhead. The Flash Attention kernel `attn_fwd.kd` accounts for all GPU time (658.46 ms). Efficiency metrics were not resolved by the analysis pipeline for this trace, so roofline-based impact estimates are unavailable.

| Metric | Value |
|--------|-------|
| Total Compute Time | 658.46 ms |
| Computation | ~100% |
| Idle Time | ~0% |
| Exposed Communication | 0% |
| Top Bottleneck Category | SDPA_fwd (100%) |

---

## Compute Kernel Optimizations

Findings from per-category kernel analysis (SDPA forward).

### Top Operations

| Rank | Category | Time (ms) | % of Compute Time | Ops | Potential improvement (time, E2E %) |
|------|----------|-----------|-------------------|-----|-------------------------------------|
| 1 | SDPA_fwd | 658.46 | 100% | 10 | — |

### 🔴 P1: Flash Attention Forward Kernel Dominates All GPU Time

**Insight**: The `attn_fwd.kd` kernel accounts for 100% of GPU compute time across 10 invocations (mean 65.85 ms/call, median 56.55 ms, range 54.18–125.69 ms), processing long sequences (32,768 tokens) with 32 attention heads and head dim 128 in BF16.

**Action**: Profile `attn_fwd.kd` with hardware counters (occupancy, wavefronts, LDS utilization, HBM throughput) for shape (1, 32, 32768, 128) on MI300X. Determine whether the kernel is compute- or memory-bound at this sequence length, then tune tile/block parameters accordingly. Investigate the ~2.3× spread between min and max call durations.

**Impact**: Not quantifiable from trace data (efficiency metrics not resolved; no pre-computed kernel_tuning estimates available).

→ *See [Detailed Analysis: Compute Kernels > 1. SDPA Forward](#1-sdpa-forward-100-of-compute) for details*

---

## System-Level Optimizations

> **Note:** System-level analysis is exploratory. The patterns and recommendations below are under active development and may be refined as system-level analysis matures.

✅ No system-level bottlenecks detected. GPU activity breakdown shows ~100% computation, with negligible memcpy and communication overhead. See [Detailed Analysis: System-Level](#detailed-analysis-system-level) for full metrics.

---

## Detailed Analysis: Compute Kernels

### 1. SDPA Forward (100% of compute)

All GPU time is in the fused Flash Attention forward kernel (`attn_fwd.kd`), processing 10 calls with identical input shapes.

| Operation | Kernel time (ms) | % of category | Count | FLOPS/Byte | Efficiency | Potential improvement (time, E2E %) |
|-----------|-----------------|---------------|-------|------------|------------|-------------------------------------|
| aten::_scaled_dot_product_flash_attention | 658.46 | 100% | 10 | — | — | — |

**Attention configuration**:
- Batch: 1, Heads (Q/KV): 32/32 (MHA), Head dim: 128
- Sequence length (Q = KV): 32,768
- Data type: BF16
- Flash Attention: Yes (`attn_fwd.kd` kernel confirmed)

**Per-call kernel duration statistics**:

| Metric | Value |
|--------|-------|
| Mean | 65,846 µs (65.85 ms) |
| Median | 56,553 µs (56.55 ms) |
| Std Dev | 21,797 µs |
| Min | 54,177 µs (54.18 ms) |
| Max | 125,690 µs (125.69 ms) |

**Key observations**:
1. **Efficiency not resolved**: The analysis pipeline did not populate efficiency metrics (tflops_achieved, bound_type, flops_per_byte are null). Peak references from platform specs: 708 TFLOPS (BF16 MAF), 5.3 TB/s (HBM BW).
2. **Call-to-call variance**: The ~2.3× spread (54.2–125.7 ms) across 10 calls with identical shapes suggests sensitivity to GPU scheduling, memory system state, or warmup effects.
3. **Already using Flash Attention**: The `flash_impl: True` flag and kernel name `attn_fwd.kd` confirm the optimized Flash Attention path is active. Optimization opportunity is at the kernel tuning level, not algorithm selection.

---

## Detailed Analysis: System-Level

> **Note:** System-level analysis is exploratory. The patterns and recommendations below are under active development and may be refined as system-level analysis matures.

<a id="cpu-idle-time-analysis"></a>
### 1. CPU/Idle Time Analysis

GPU idle time is ~0%, well below the 15% threshold. No action required.

| Metric | Value |
|--------|-------|
| Total GPU Time | 658.46 ms |
| Computation | 100.0% |
| Idle | 0.0% |
| Communication | 0.0% |
| MemCpy | 0.0% |

<a id="multi-kernel-issues"></a>
### 2. Multi-Kernel Issues

No multi-kernel issues detected. Zero memcpy transfers and zero NCCL collective operations were observed. Communication/compute overlap is not applicable.

---

## Appendix

### Model Architecture
- **Model**: Cannot be inferred from trace
- **Architecture**: Cannot be inferred from trace
- **Scale**: Cannot be inferred from trace
- **Precision**: BF16

### Hardware Reference
- **Platform**: MI300X
- **Peak HBM BW**: 5.3 TB/s
- **Peak MAF (BF16)**: 708 TFLOPS
- **Peak MAF (FP16)**: 654 TFLOPS
- **Peak MAF (FP8)**: 1273 TFLOPS
- **Peak MAF (FP32)**: 163 TFLOPS
